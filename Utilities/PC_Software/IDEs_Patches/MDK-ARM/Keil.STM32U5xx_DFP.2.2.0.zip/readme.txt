/**
  ***************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U5xx devices support on MDK-ARM.
  ***************************************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32U5xx 
  devices by MDK-ARM v5.37 and laters.

  Running "Keil.STM32U5xx_DFP.2.2.0.pack" adds the following:
  ==============================================================
  
  1. Part numbers for  :
   - Part line with 4MB Flash size   :STM32U595xJxx / STM32U5A5xJxx / STM32U599xJxx / STM32U5A9xJxx / STM32U5F9xJxx / STM32U5G9xJxx / STM32U5G7xJxx / STM32U5F7xJxx.
   - Product line with 2MB Flash size: STM32U595xIxx / STM32U5A5xIxx / STM32U599xIxx / STM32U5A9xIxx / STM32U575xI/U585xI /STM32U5F9xIxx / STM32U5F7xIxx
   - Product line with 1MB Flash size: STM32U575xG
   - Product line with 512KB Flash size: STM32U535xExx/U545xExx
   - Product line with 256KB Flash size: STM32U535xCxx
   - Product line with 128KB Flash size: STM32U535xBxx
   
  2. Automatic STM32U5 flash algorithm selection
   - Internal secure and non-secure Flash loader support
   - STM32U575I-EVAL dedicated connection with OSPI external loader support
   - STM32U585I-IOT02A dedicated connection with OSPI external loader support
   - STM32U5x9J-DK dedicated connection with OSPI external loader support  
   
  3. SVD files for STM32U575; STM32585; STM32U599; STM32U595; STM32U5A9; STM32U5A5; STM32U535; STM32U545; STM32U5Fx; STM32U5Gx;


  How to use:
  ==========
  * Before installing the files mentioned above, you need to have MDK-ARM v5.37 or later installed. 
  You can download pack from keil web site @ www.keil.com
 
  * Double Clic on  "Keil.STM32U5xx_DFP.2.2.0.pack" in order to install this pack in the Keil install 
  directory.
